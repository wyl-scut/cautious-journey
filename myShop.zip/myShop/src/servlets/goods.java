package servlets;

import java.util.logging.*;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/g")
public class goods extends HttpServlet {
	//Logger log = Logger.getLogger("servlet.userList");
	public goods() {
        super(); 
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
	
	    String admin=request.getParameter("admin");
		request.setCharacterEncoding("UTF-8");
		String JDriver="com.mysql.cj.jdbc.Driver";
		String conURL="jdbc:mysql://localhost:3306/test1?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
		Connection con = null;
		Statement stm=null;
		ResultSet rs = null;
		RequestDispatcher dispatcher = null;
		try {
			Class.forName(JDriver);
			con=DriverManager.getConnection(conURL,"root","Ab123456");
			ArrayList<Object[]> goodslist = new ArrayList<Object[]>();
			stm=con.createStatement();
			rs=stm.executeQuery("select*from goods");
			while(rs.next()) {
				String id = rs.getString("id");
				String goods_name = rs.getString("goods_name");
				String number = rs.getString("number");
				String goods_img = rs.getString("goods_img");
				String price = rs.getString("price");
				goodslist.add(new Object[] {id,goods_name,number,goods_img,price});
	//			log.info("锟斤拷取锟矫伙拷锟斤拷息锟斤拷"+id+' '+goods_name+' '+number);
				}
			request.setAttribute("goodslist", goodslist);
			HttpSession session=request.getSession();
			session.setAttribute("goodslist", goodslist);
			if(admin!=null&&admin.equals("1")) {
				dispatcher = getServletContext().getRequestDispatcher("/admin_goods.jsp");
			}
			else {
			dispatcher = getServletContext().getRequestDispatcher("/goods.jsp");}
			dispatcher.forward(request, response);
		}catch(Exception e) {
	//		log.info("锟斤拷取锟矫伙拷注锟斤拷锟绞э拷锟�");
			request.setAttribute("errorInfo", "锟斤拷取锟矫伙拷注锟斤拷锟绞э拷锟�"+e.getMessage());
			if(admin!=null&&admin.equals("1")) {
				dispatcher = getServletContext().getRequestDispatcher("/admin_goods.jsp");
			}
			else {
			dispatcher=getServletContext().getRequestDispatcher("/goods.jsp");}
			dispatcher.forward(request, response);
		}finally {
			try {
				if(stm!=null) {
					stm.close();
					stm=null;
				}
				if(con!=null) {
					con.close();
					con=null;
				}
			}catch(SQLException e) {
//				log.info("锟斤拷锟捷库处锟斤拷锟斤拷锟�");
				e.printStackTrace();
			}
		}
		
		}

	}
	

