// UserRegisterServlet.java
package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UserRegisterServlet extends HttpServlet
{
	//Logger log = Logger.getLogger("servlet.register");
    private static final long serialVersionUID = 1L;
   // private void logInit() throws SecurityException, IOException {
	//	FileHandler fh = new FileHandler("register.log");
	//	fh.setFormatter(new SimpleFormatter());
	//	log.addHandler(fh);
	//}
    @Override
    protected void doGet(HttpServletRequest req,HttpServletResponse resp) throws ServletException,IOException
    {
        this.doPost(req,resp);
    }
    /*
    put user,password,driver and url here.
    */
    @Override
    protected void doPost(HttpServletRequest req,HttpServletResponse resp) throws ServletException,IOException
    {
    	req.setCharacterEncoding("UTF-8");
    	//logInit();
        String JDriver="com.mysql.cj.jdbc.Driver";
        String conURL="jdbc:mysql://localhost:3306/test1?&characterEncoding=utf8&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
        Connection con = null;
        PreparedStatement pstm=null;
        ResultSet rs= null;
        //锟斤拷锟斤拷址锟�
        RequestDispatcher dispatcher = null;
        try
        {
            //get parameter
            String userName = req.getParameter("userName");
            String userPWD = req.getParameter("userPWD");
            String tel = req.getParameter("tel");
            String address = req.getParameter("address");
            System.out.println("----------------------------------------");
            System.out.println(userName);
     //       log.info("锟斤拷取锟斤拷息锟斤拷"+userName+" "+address);
            //parameter useful
            if(userName==null||userName.trim().equals(""))throw new Exception("用户名不能为空");
            if(userPWD==null||userPWD.trim().equals(""))throw new Exception("密码不能为空");
            if(tel==null)tel="";
            if(address==null)address="";
      //      log.info("---");
            //JDBC driver
            Class.forName(JDriver);
           
         //   log.info("2");
            //connect to DBurl
            con=DriverManager.getConnection(conURL,"root","Ab123456");
      //      log.info("3");
            if(con==null) {
       //     	log.info("锟斤拷锟斤拷锟斤拷锟斤拷sql");
            }
            
            //preparedStatement travel to sql 
  //          log.info("4");
            pstm=con.prepareStatement("select * from login where name=?");
    //        log.info("5");
            pstm.setString(1,userName);
    //        log.info("6");
            rs=pstm.executeQuery();
    //        log.info("7");
            //userName exist?
            if(rs.next()){
         //   	log.info("锟矫伙拷锟斤拷锟斤拷锟斤拷");
                throw new Exception("用户名重复");
            }
        //    log.info("8");
            //update
          //  String A=new String(userName.getBytes("ISO-8859-1"),"utf-8");
            System.out.println("===========================");
            System.out.println(userName);
            pstm=con.prepareStatement("insert into login(name,pwd,tel,address) value(?,?,?,?)");
            pstm.setString(1,userName);
            pstm.setString(2,userPWD);
            pstm.setString(3,tel);
            pstm.setString(4,address);
            pstm.execute();
       //     log.info("9");
            //锟斤拷锟斤拷request attribute锟斤拷锟斤拷值锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
            req.setAttribute("successInfo","注册成功");
 //           log.info("锟斤拷锟矫伙拷注锟斤拷晒锟斤拷锟�");
            //锟斤拷应request 转锟斤拷页锟斤拷
            dispatcher=getServletContext().getRequestDispatcher("/userRegister.jsp");
            dispatcher.forward(req, resp);
        }
        catch(Exception e) {
    //    	log.info("锟睫凤拷锟斤拷锟斤拷sql");
        	req.setAttribute("errorInfo",e.getMessage());
        	dispatcher = getServletContext().getRequestDispatcher("/userRegister.jsp");
        	dispatcher.forward(req, resp);
        }
       finally {
        	try {
        		if(pstm!=null) {
        			pstm.close();
        			pstm=null;
        		}
        		if(con!=null) {
        			con.close();
        			con=null;
        		}
        	}catch(SQLException e){
        		e.printStackTrace();
        	}
        }
    }
}