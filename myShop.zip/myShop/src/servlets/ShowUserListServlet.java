package servlets;

import java.util.ArrayList;
import java.util.logging.*;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



public class ShowUserListServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
//	Logger log = Logger.getLogger("servlet.userList");
	
	@Override
	protected void doGet(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
		this.doPost(req,resp);
	}
	@Override
	protected void doPost(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
	
		req.setCharacterEncoding("UTF-8");
		String JDriver="com.mysql.cj.jdbc.Driver";
		String conURL="jdbc:mysql://localhost:3306/test1?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
		Connection con = null;
		Statement stm=null;
		ResultSet rs = null;
		RequestDispatcher dispatcher = null;
		try {
			Class.forName(JDriver);
			con=DriverManager.getConnection(conURL,"root","Ab123456");
			ArrayList<Object[]> userList = new ArrayList<Object[]>();
			stm=con.createStatement();
			rs=stm.executeQuery("select*from login");
			while(rs.next()) {
				String name = rs.getString("name");
				String tel = rs.getString("tel");
				String address = rs.getString("address");
				String head = rs.getString("head_img");
				userList.add(new Object[] {name,tel,address,head});
			}
			HttpSession session = req.getSession();
			session.setAttribute("userList", userList);
			dispatcher = getServletContext().getRequestDispatcher("/loginSuccess.jsp");
			dispatcher.forward(req, resp);
			
		}catch(Exception e) {

			dispatcher=getServletContext().getRequestDispatcher("/loginSuccess.jsp");
			dispatcher.forward(req, resp);
		}finally {
			try {
				if(stm!=null) {
					stm.close();
					stm=null;
				}
				if(con!=null) {
					con.close();
					con=null;
				}
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	
}
