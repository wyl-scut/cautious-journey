package servlets;

public class email {

}
