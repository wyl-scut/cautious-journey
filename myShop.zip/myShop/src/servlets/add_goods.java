


// UserRegisterServlet.java
package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.cj.xdevapi.Statement;
@WebServlet("/add_goods")
public class add_goods extends HttpServlet
{


    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req,HttpServletResponse resp) throws ServletException,IOException
    {
		req.setCharacterEncoding("UTF-8");
        String JDriver="com.mysql.cj.jdbc.Driver";
        String conURL="jdbc:mysql://localhost:3306/test1?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
        Connection con = null;
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test1?", "root", "Ab123456");
		} catch (SQLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
        PreparedStatement pstm=null;
        java.sql.Statement stm=null;
        ResultSet rs= null;
        String goods_id=req.getParameter("goods_id");
        String goods_name=req.getParameter("goods_name");
        String goods_number=req.getParameter("goods_number");
        String goods_img=req.getParameter("goods_img");
        String goods_price=req.getParameter("goods_price");
    	Object ob = new Object[] {goods_id,goods_name,goods_number,goods_img,goods_price};
    	System.out.println("get the info from goods");
    	System.out.println(goods_id);
    	System.out.println(goods_img);
    	String delete_id="";
        try
        {    
          
        	
        	int count=0;
        	ArrayList<Object[]> userList = new ArrayList<Object[]>();
			stm=con.createStatement();
			rs=((java.sql.Statement) stm).executeQuery("select*from goods");
			while(rs.next()) {
				String id = rs.getString("id");
				//String name = rs.getString("goods_name");
				//String number = rs.getString("number");
				//String img = rs.getString("goods_img");
				//userList.add(new Object[] {id,goods_name,number,goods_img});
				//log.info("锟斤拷取锟矫伙拷锟斤拷息锟斤拷"+name+' '+tel+' '+address);
				if(id.equals(goods_id)) {
					if(goods_id==null||goods_id.length()==0) {
						goods_id=rs.getString("id");
					}
					if(goods_name==null||goods_name.length()==0) {
					goods_name=rs.getString("goods_name");
					}
					if(goods_number==null||goods_number.length()==0) {
					goods_number=rs.getString("number");
					}
					if(goods_img==null||goods_img.length()==0) {
					goods_img=rs.getString("goods_img");
					}
					if(goods_price==null||goods_price.length()==0) {
					goods_price=rs.getString("price");
					}
					count=1; 
					delete_id=goods_id;
				}
			if(count==1) {
				String sql = "delete from goods where id = '" + delete_id+"'";
	            //4. 创建Statement对象
	            //   建立到特定数据库的连接之后，就可用该连接发送SQL语句;
	            //   Statement对象用 Connection() 的方法 createStatement 创建
	            java.sql.Statement s = con.createStatement();
	            //5. 定义一个变量row用于接收executeUpdate()的返回值0/1,即查询到的结果是否存在，存在就删除，返回删除的个数
	            int row = s.executeUpdate(sql);
	            if(row != 0){
	                //row如果为0，即删除成功
	                System.out.println("删除成功");

	            }else{
	                //row为1，输出失败
	                System.out.println("删除失败");
	            }
	            //6. 关闭连接，释放资源
	           // con.close();
	            //s.close();
	            }
			
			}
			
			pstm=con.prepareStatement("insert into goods(id,goods_name,number,goods_img,price) value(?,?,?,?,?)");
            pstm.setString(1,goods_id);
            pstm.setString(2,goods_name);
            pstm.setString(3,goods_number);
            pstm.setString(4,goods_img);
            pstm.setString(5,goods_price);
            pstm.execute();
			
			//req.setAttribute("userList", userList);
			HttpSession session = req.getSession();
			//session.setAttribute("userList", userList);
        	
           
    
        
        
			RequestDispatcher dispatcher = null;
			stm = null;
			try {
				Class.forName(JDriver);
				con=DriverManager.getConnection(conURL,"root","Ab123456");
				ArrayList<Object[]> goodslist = new ArrayList<Object[]>();
				stm=con.createStatement();
				rs=stm.executeQuery("select*from goods");
				while(rs.next()) {
					goods_id = rs.getString("id");
					goods_name = rs.getString("goods_name");
					goods_number = rs.getString("number");
					goods_img = rs.getString("goods_img");
					goods_price=rs.getString("price");
					
					goodslist.add(new Object[] {goods_id,goods_name,goods_number,goods_img,goods_price});
					
					}
				//req.setAttribute("goodslist", goodslist);
				//HttpSession session=req.getSession();
				session.setAttribute("goodslist", goodslist);
				dispatcher = getServletContext().getRequestDispatcher("/admin_goods.jsp");
				dispatcher.forward(req, resp);
			}catch(Exception e) {
				//log.info("锟斤拷取锟矫伙拷注锟斤拷锟绞э拷锟�");
				req.setAttribute("errorInfo", "无法查询商品数据库"+e.getMessage());
				dispatcher=getServletContext().getRequestDispatcher("/admin_goods.jsp");
				dispatcher.forward(req, resp);
			}finally {
				
			}} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        
        finally {
        RequestDispatcher dispatcher1 = null;
        dispatcher1=getServletContext().getRequestDispatcher("/admin_goods.jsp");
		dispatcher1.forward(req,resp);
        }
        }
    
    protected void doPost(HttpServletRequest req,HttpServletResponse resp) throws ServletException,IOException
    {
    	this.doGet(req, resp);
    }
}
