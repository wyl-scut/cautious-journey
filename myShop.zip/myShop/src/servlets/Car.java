package servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
 
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
 
/**
 * Servlet implementation class Car
 */
@WebServlet("/Car")
public class Car extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Car() {
        super();
        // TODO Auto-generated constructor stub
    }
 
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.getWriter().append("Served at: ").append(request.getContextPath());
		//鑾峰彇鐐瑰嚮璐墿閭ｄ釜鍟嗗搧鐨処D锛圫tring锛夛紝姣忔鍙槸鐐瑰嚮涓�涓�,鎵�浠D灏辨槸涓�涓暟鍙互杞负int
		String id=request.getParameter("id");
		HttpSession session=request.getSession();
		ArrayList<Object[]> goodslist = (ArrayList<Object[]>) session.getAttribute("goodslist");
		String names[]= new String[goodslist.size()];
		for(int i=0;i<goodslist.size();i++)
		{
			names[i]=(String) goodslist.get(i)[1];
		}
		
		
		
		
		//String[] names=new String[] {"iPhone","goods_2","goods_3","goods_4","goods_5","goods_6",};
		int index=Integer.parseInt(id);
		if(index!=0) {String productname=names[index-1];
		@SuppressWarnings("unchecked")
		Map<String,Integer> car=(Map<String,Integer>)session.getAttribute("car");
		if(car==null) {
			//濡傛灉璐墿杞︿负绌哄垯鍒涘缓涓�涓猰ap鐢ㄦ潵瀛樺偍锛屾斁鍒拌溅閲宮ap锛岀劧鍚庢斁鍒皊ession涓�
			car=new HashMap<String,Integer>();
			car.put(productname, 1);
			session.setAttribute("car", car);
		}else {
			if(car.containsKey(productname)) {
				//棣栧厛瑕佸垽鏂槸鍚︽湁锛屾湁鐨勮瘽鍒欏姞涓�
				Integer count=car.get(productname);
				count++;
				car.put(productname, count);
				session.setAttribute("car", car);
			}else {
				//娌℃湁鐨勮瘽鏁伴噺鍒欎粠1寮�濮�
				car.put(productname, 1);
				session.setAttribute("car", car);
			}
		}
		}
		else {
			//HttpSession session=request.getSession();
			Map<String,Integer> car=(Map<String,Integer>)session.getAttribute("car");
			car=null;
			session.setAttribute("car", null);
		}
		//閲嶅畾鍚戝埌涓嬩竴涓〉闈�
		if(index!=0) {response.sendRedirect(request.getContextPath()+"/goods.jsp");}
		else {response.sendRedirect(request.getContextPath()+"/over.jsp");}
	}
 
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
 
}

