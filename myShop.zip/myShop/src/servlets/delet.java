


// UserRegisterServlet.java
package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.cj.xdevapi.Statement;
@WebServlet("/delet")
public class delet extends HttpServlet
{


    protected void doGet(HttpServletRequest req,HttpServletResponse resp) throws ServletException,IOException
    {
    	req.setCharacterEncoding("UTF-8");
        String JDriver="com.mysql.cj.jdbc.Driver";
        String conURL="jdbc:mysql://localhost:3306/test1?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
        Connection con = null;
        PreparedStatement pstm=null;
        ResultSet rs= null;
        try
        {    
           String id=(String) req.getParameter("name");
           System.out.println("delete from login where name = '" + id+"'");
        	//1. 注册驱动（mysql5 之后 注册驱动操作可以省略）
            Class.forName("com.mysql.jdbc.Driver");
            //2. 获取数据库连接对象
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test1?", "root", "Ab123456");
            //3. 执行SQL语句
            String sql = "delete from login where name = '" + id+"'";
            //4. 创建Statement对象
            //   建立到特定数据库的连接之后，就可用该连接发送SQL语句;
            //   Statement对象用 Connection() 的方法 createStatement 创建
            java.sql.Statement s = conn.createStatement();
            //5. 定义一个变量row用于接收executeUpdate()的返回值0/1,即查询到的结果是否存在，存在就删除，返回删除的个数
            int row = s.executeUpdate(sql);
            if(row != 0){
                //row如果为0，即删除成功
                System.out.println("删除成功");

            }else{
                //row为1，输出失败
                System.out.println("删除失败");

            }
            //6. 关闭连接，释放资源
            conn.close();
            s.close();}

        catch(Exception e) {
        	

        	//dispatcher.forward(req, resp);
        }
       finally {
        	try {
        		if(pstm!=null) {
        			pstm.close();
        			pstm=null;
        		}
        		if(con!=null) {
        			con.close();
        			con=null;
        		}
        	}catch(SQLException e){
        		e.printStackTrace();
        	}}
        RequestDispatcher dispatcher = null;
        dispatcher=getServletContext().getRequestDispatcher("/showUserList");
		dispatcher.forward(req,resp);
        
        }
    
    protected void doPost(HttpServletRequest req,HttpServletResponse resp) throws ServletException,IOException
    {
    	this.doGet(req, resp);
    }
}
