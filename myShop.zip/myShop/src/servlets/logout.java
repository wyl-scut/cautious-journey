package servlets;

import java.util.logging.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/logout")
public class logout extends HttpServlet {
	private static final long serialVersionUID=1L;
	//Logger log = Logger.getLogger("servlet.login");
	@Override
	protected void doGet(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
		this.doPost(req,resp);
	}
	@Override
	protected void doPost(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
		String JDriver="com.mysql.cj.jdbc.Driver";
		String conURL="jdbc:mysql://localhost:3306/test1?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
		req.setCharacterEncoding("UTF-8");
		Connection con=null;
		PreparedStatement pstm=null;
		ResultSet rs=null;
		RequestDispatcher dispatcher=null;
		//FileHandler fh= new FileHandler("servlet_login.log");
		//fh.setFormatter(new SimpleFormatter());
	//	log.addHandler(fh);
		try
		{
			String userName = req.getParameter("userName");
			String userPWD=req.getParameter("userPWD");
			
			if(userName==null||userName.trim().equals("")) {
				throw new Exception("用户名不能为空");
			}
			if(userPWD==null||userPWD.trim().equals("")) {
				throw new Exception("密码不能为空");
			}
			//userName=new String(userName.getBytes("8859_1"),"GBK");
			//userPWD=new String(userPWD.getBytes("8859_1"),"GBK");
			Class.forName(JDriver);
			con=DriverManager.getConnection(conURL,"root","Ab123456");
			pstm=con.prepareStatement("select*from login where name=? and pwd=?");
			pstm.setString(1,userName);
			pstm.setNString(2, userPWD);
			rs=pstm.executeQuery();
			if(rs.next()) {

				   try
			        {    
			           
			           System.out.println("delete from login where name = '" + userName+"'");
			        	//1. 注册驱动（mysql5 之后 注册驱动操作可以省略）
			            Class.forName("com.mysql.jdbc.Driver");
			            //2. 获取数据库连接对象
			            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test1?", "root", "Ab123456");
			            //3. 执行SQL语句
			            String sql = "delete from login where name = '" + userName+"'";
			            //4. 创建Statement对象
			            //   建立到特定数据库的连接之后，就可用该连接发送SQL语句;
			            //   Statement对象用 Connection() 的方法 createStatement 创建
			            java.sql.Statement s = conn.createStatement();
			            //5. 定义一个变量row用于接收executeUpdate()的返回值0/1,即查询到的结果是否存在，存在就删除，返回删除的个数
			            int row = s.executeUpdate(sql);
			            if(row != 0){
			                //row如果为0，即删除成功
			            	req.setAttribute("errorInfo","删除成功" );
			            	//throw new Exception();
			              //  System.out.println("");

			            }else{
			                //row为1，输出失败
			              //  System.out.println("删除失败");
			            //	throw new Exception("删除失败");
			            }
			            //6. 关闭连接，释放资源
			          
			        }

			        catch(Exception e) {
			        	

			        	//dispatcher.forward(req, resp);
			        }
			       finally {
			        	try {
			        		if(pstm!=null) {
			        			pstm.close();
			        			pstm=null;
			        		}
			        		if(con!=null) {
			        			con.close();
			        			con=null;
			        		}
			        	}catch(SQLException e){
			        		e.printStackTrace();
			        	}
				
				
				
				
				dispatcher=getServletContext().getRequestDispatcher("/logout.jsp");
				dispatcher.forward(req,resp);
			}}
			else {
				throw new Exception("账号或密码错误");
			}
		    }
		catch(Exception e) {
		
			req.setAttribute("errorInfo", e.getMessage());
			dispatcher=getServletContext().getRequestDispatcher("/logout.jsp");
			dispatcher.forward(req,resp);
		}
		finally {
			try {
				if(pstm!=null) {
					pstm.close();
					pstm=null;
				}
				if(con!=null) {
					con.close();
					con=null;
				}
			}catch(SQLException e){
		//		log.info("denglushibai");
			}
		
		}
	}
}
